#!/bin/bash
 
function killdyn() {
 
# This function kills all existing dynamips and dynagen processes
 
 echo "Killing any existing Dynamips processes ..."
 
 pkill -9 dynamips
 
 pkill -9 dynagen
 
}
 
#
 
function startdyn() {
 
# This function starts the dynamips hypervisors
 
echo "Initializing Dynamips Hypervisors ..."
 
/usr/bin/dynamips -H 7200 > /dev/null 2>&1 &
 
}
 
#
 
clear
 

 
 clear
echo "***********************************************************************************************************************"
 
echo "*                                                                                                                     *"
 
echo "*        CCCCCCCCCCCCC       CCCCCCCCCCCCCIIIIIIIIIIEEEEEEEEEEEEEEEEEEEEEE        SSSSSSSSSSSSSSS PPPPPPPPPPPPPPPPP   *"
echo "*     CCC::::::::::::C    CCC::::::::::::CI::::::::IE::::::::::::::::::::E      SS:::::::::::::::SP::::::::::::::::P  *"
echo "*   CC:::::::::::::::C  CC:::::::::::::::CI::::::::IE::::::::::::::::::::E     S:::::SSSSSS::::::SP::::::PPPPPP:::::P *"
echo "*  C:::::CCCCCCCC::::C C:::::CCCCCCCC::::CII::::::IIEE::::::EEEEEEEEE::::E     S:::::S     SSSSSSSPP:::::P     P:::::P*"
echo "* C:::::C       CCCCCCC:::::C       CCCCCC  I::::I    E:::::E       EEEEEE     S:::::S              P::::P     P:::::P*"
echo "*C:::::C             C:::::C                I::::I    E:::::E                  S:::::S              P::::P     P:::::P*"
echo "*C:::::C             C:::::C                I::::I    E::::::EEEEEEEEEE         S::::SSSS           P::::PPPPPP:::::P *"
echo "*C:::::C             C:::::C                I::::I    E:::::::::::::::E          SS::::::SSSSS      P:::::::::::::PP  *"
echo "*C:::::C             C:::::C                I::::I    E:::::::::::::::E            SSS::::::::SS    P::::PPPPPPPPP    *"
echo "*C:::::C             C:::::C                I::::I    E::::::EEEEEEEEEE               SSSSSS::::S   P::::P            *"
echo "*C:::::C             C:::::C                I::::I    E:::::E                              S:::::S  P::::P            *"
echo "* C:::::C       CCCCCCC:::::C       CCCCCC  I::::I    E:::::E       EEEEEE                 S:::::S  P::::P            *"
echo "*  C:::::CCCCCCCC::::C C:::::CCCCCCCC::::CII::::::IIEE::::::EEEEEEEE:::::E     SSSSSSS     S:::::SPP::::::PP          *"
echo "*   CC:::::::::::::::C  CC:::::::::::::::CI::::::::IE::::::::::::::::::::E     S::::::SSSSSS:::::SP::::::::P          *"
echo "*     CCC::::::::::::C    CCC::::::::::::CI::::::::IE::::::::::::::::::::E     S:::::::::::::::SS P::::::::P          *"
echo "*        CCCCCCCCCCCCC       CCCCCCCCCCCCCIIIIIIIIIIEEEEEEEEEEEEEEEEEEEEEE      SSSSSSSSSSSSSSS   PPPPPPPPPP          *"
echo "*                                                                                                                     *"
echo "*   Darren O'Connor - INE SP CCIE Labs                                                                                *"
echo "*   http://www.mellowd.co.uk/ccie  -  Originally from http://www.astorinonetworks.com                                 *"
echo "***********************************************************************************************************************"
 

 startdyn;
nexec gnome-terminal -t "test" -e "telnet nO" & | /usr/bin/dynagen /home/hanane/Dynamips/lab/topologie.net

